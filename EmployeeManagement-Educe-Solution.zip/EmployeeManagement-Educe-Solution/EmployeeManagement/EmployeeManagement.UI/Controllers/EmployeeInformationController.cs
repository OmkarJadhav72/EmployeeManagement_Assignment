﻿using EmployeeManagement.BusinessAccessLayer.Interface;
using EmployeeManagement.Domain.Entity;
using EmployeeManagement.UI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.UI.Controllers
{
    public class EmployeeInformationController : Controller
    {
        private readonly IEmployeesService _employeesService;
        private readonly ILogger<EmployeeInformationController> _logger;

        public EmployeeInformationController(
            IEmployeesService employeesService,
            ILogger<EmployeeInformationController> logger)
        {
            _employeesService = employeesService;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            _logger.LogInformation("EmpInfo Index page requested");

            try
            {
                var model = new EmployeeViewModel
                {
                    empInfo = new Employee(),
                    empList = _employeesService.GetAllEmployees(),
                    cities = _employeesService.GetAllDropDownCity(),
                    states = _employeesService.GetAllDropDownState()
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading Index page");
                return Content(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Create(EmployeeViewModel model)
        {
            _logger.LogInformation("Create/Update employee request received");

            try
            {
                var data = model.empInfo;

                if (data.EmployeeId != 0)
                {
                    _logger.LogInformation("Updating employee Id {EmployeeId}", data.EmployeeId);
                    _employeesService.UpdateEmployee(data);
                }
                else
                {
                    _logger.LogInformation("Adding new employee");
                    _employeesService.AddEmployee(data);
                }

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Create action");
                return Content(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            _logger.LogInformation("Edit request for employee Id {EmployeeId}", Id);

            try
            {
                var model = new EmployeeViewModel
                {
                    empInfo = _employeesService.GetEmployeeById(Id),
                    empList = _employeesService.GetAllEmployees(),
                    cities = _employeesService.GetAllDropDownCity(),
                    states = _employeesService.GetAllDropDownState()
                };

                return View("Index", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading Edit page");
                return Content(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult Delete(int Id)
        {
            _logger.LogInformation("Delete request for employee Id {EmployeeId}", Id);

            try
            {
                _employeesService.DeleteEmployee(Id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting employee");
                return Content(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult Details(int Id)
        {
            _logger.LogInformation("Details requested for employee Id {EmployeeId}", Id);

            try
            {
                var emp = _employeesService.GetEmployeeById(Id);

                var model = new EmployeeViewModel
                {
                    empInfo = emp
                };

                return PartialView("_Details", model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading employee details");
                return Content(ex.Message);
            }
        }
    }
}
