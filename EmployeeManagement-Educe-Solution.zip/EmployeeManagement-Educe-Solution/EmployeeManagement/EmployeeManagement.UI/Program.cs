using EmployeeManagement.BusinessAccessLayer.Interface;
using EmployeeManagement.DataAccessLayer.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .CreateLogger();

builder.Host.UseSerilog();


builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IEmployeesService, EmployeesService>();

var app = builder.Build();


app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();


app.MapControllerRoute(
    name: "default",
    pattern: "{controller=EmployeeInformation}/{action=Index}/{id?}");

app.Run();
