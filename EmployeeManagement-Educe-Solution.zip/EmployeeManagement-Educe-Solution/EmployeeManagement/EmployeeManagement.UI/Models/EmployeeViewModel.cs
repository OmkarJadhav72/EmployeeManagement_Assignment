﻿using EmployeeManagement.Domain.Entity;

namespace EmployeeManagement.UI.Models
{
    public class EmployeeViewModel
    {
        public Employee empInfo { get; set; }
        public List<Employee> empList { get; set; }
        public List<City> cities { get; set; }
        public List<State> states { get; set; }
    }
}
