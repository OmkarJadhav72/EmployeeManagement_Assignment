﻿using EmployeeManagement.BusinessAccessLayer.Interface;
using EmployeeManagement.Domain.Entity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace EmployeeManagement.DataAccessLayer.Services
{
    public class EmployeesService : IEmployeesService
    {
        private readonly ILogger<EmployeesService> _logger;
        private readonly string _connectionString;

        public EmployeesService(
            ILogger<EmployeesService> logger,
            IConfiguration configuration)
        {
            _logger = logger;
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public int AddEmployee(Employee employee)
        {
            _logger.LogInformation("Start AddEmployee");

            int result = 0;
            try
            {
                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("AddEmployee", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FullName", employee.FullName);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@State", employee.State);
                cmd.Parameters.AddWithValue("@City", employee.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", employee.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", employee.IsActive);
                cmd.Parameters.AddWithValue("@CreatedBy", employee.CreatedBy);
                cmd.Parameters.AddWithValue("@CreatedOn", employee.CreatedOn);
                cmd.Parameters.AddWithValue("@UpdatedBy", employee.UpdatedBy);
                cmd.Parameters.AddWithValue("@UpdatedOn", employee.UpdatedOn);

                result = cmd.ExecuteNonQuery();
                conn.Close();

                _logger.LogInformation("End AddEmployee");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in AddEmployee");
            }

            return result;
        }

        public int DeleteEmployee(int employeeId)
        {
            _logger.LogInformation("Deleting employee with Id {EmployeeId}", employeeId);

            try
            {
                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("DeleteEmployee", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                int result = cmd.ExecuteNonQuery();
                conn.Close();

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting employee");
                throw;
            }
        }

        public List<Employee> GetAllActiveEmp()
        {
            List<Employee> result = new List<Employee>();
            SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("GetAllActiveEmp",conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Employee emp = new Employee
                {
                    EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                    FullName = Convert.ToString(reader["FullName"]),
                    Email = Convert.ToString(reader["Email"]),
                    State = Convert.ToString(reader["State"]),
                    City = Convert.ToString(reader["City"]),
                    DateOfJoining = Convert.ToDateTime(reader["DateOfJoining"]),
                    IsActive = Convert.ToBoolean(reader["IsActive"])

                };

                result.Add(emp);
            }
            reader.Close();
            conn.Close();
            return result;
        }

        public List<City> GetAllDropDownCity()
        {
            List<City> list = new List<City>();
            SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("GetAllCitys", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                City city = new City();
                city.CityId = Convert.ToInt32(reader["CityId"]);
                city.CityName = Convert.ToString(reader["CityName"]);
                list.Add(city);
            }
            reader.Close();
            conn.Close();
            return list;
        }

        public List<State> GetAllDropDownState()
        {
            List<State> list = new List<State>();
            SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("GetAllStates", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                State state = new State();
                state.StateId = Convert.ToInt32(reader["StateId"]);
                state.StateName = Convert.ToString(reader["StateName"]);
                list.Add(state);
            }
            reader.Close();
            conn.Close();
            return list;
        }

        public List<Employee> GetAllEmployees()
        {
            _logger.LogInformation("Fetching all employees");

            try
            {
                List<Employee> employees = new List<Employee>();
                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("GetAllEmployees", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Employee emp = new Employee
                    {
                        EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                        FullName = Convert.ToString(reader["FullName"]),
                        Email = Convert.ToString(reader["Email"]),
                        State = Convert.ToString(reader["State"]),
                        City = Convert.ToString(reader["City"]),
                        DateOfJoining = Convert.ToDateTime(reader["DateOfJoining"])
                    };

                    employees.Add(emp);
                }

                reader.Close();
                conn.Close();

                return employees;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching employees");
                throw;
            }
        }

        public Employee GetEmployeeById(int employeeId)
        {
            _logger.LogInformation("Fetching employee by Id {EmployeeId}", employeeId);

            try
            {
                Employee emp = null;
                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("GetByIdEmployee", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    emp = new Employee
                    {
                        EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                        FullName = Convert.ToString(reader["FullName"]),
                        Email = Convert.ToString(reader["Email"]),
                        State = Convert.ToString(reader["State"]),
                        City = Convert.ToString(reader["City"]),
                        DateOfJoining = Convert.ToDateTime(reader["DateOfJoining"]),
                        IsActive = Convert.ToBoolean(reader["IsActive"])
                    };
                }

                reader.Close();
                conn.Close();

                return emp;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching employee by Id");
                throw;
            }
        }

        public int UpdateEmployee(Employee emp)
        {
            _logger.LogInformation("Updating employee {EmployeeId}", emp.EmployeeId);

            try
            {
                SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                SqlCommand cmd = new SqlCommand("UpdateEmployee", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeId", emp.EmployeeId);
                cmd.Parameters.AddWithValue("@FullName", emp.FullName);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@State", emp.State);
                cmd.Parameters.AddWithValue("@City", emp.City);
                cmd.Parameters.AddWithValue("@DateOfJoining", emp.DateOfJoining);
                cmd.Parameters.AddWithValue("@IsActive", emp.IsActive);
               

                int result = cmd.ExecuteNonQuery();
                conn.Close();

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating employee");
                throw;
            }
        }
    }
}
