﻿

using EmployeeManagement.Domain.Entity;


namespace EmployeeManagement.BusinessAccessLayer.Interface
{
    public interface IEmployeesService
    {
        int AddEmployee(Employee employee);
        int UpdateEmployee(Employee employee);
        int DeleteEmployee(int employeeId);
        List<Employee> GetAllEmployees();
        Employee GetEmployeeById(int employeeId);
        List<City> GetAllDropDownCity();
        List<State> GetAllDropDownState();
        List<Employee> GetAllActiveEmp();

    }
}
