using EmployeeManagement.BusinessAccessLayer.Interface;
using EmployeeManagement.DataAccessLayer.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);


builder.Host.UseSerilog((context, services, configuration) =>
{
    configuration
        .ReadFrom.Configuration(context.Configuration)
        .Enrich.FromLogContext();
});

builder.Services.AddControllers();
builder.Services.AddTransient<IEmployeesService, EmployeesService>();

var app = builder.Build();

app.UseAuthorization();
app.MapControllers();

app.Run();
