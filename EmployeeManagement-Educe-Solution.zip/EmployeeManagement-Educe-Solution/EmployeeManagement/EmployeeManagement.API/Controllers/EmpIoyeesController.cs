﻿using EmployeeManagement.BusinessAccessLayer.Interface;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.API.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeesService _employeesService;
        private readonly ILogger<EmployeesController> _logger;

        public EmployeesController(
            IEmployeesService employeesService,
            ILogger<EmployeesController> logger)
        {
            _employeesService = employeesService;
            _logger = logger;
        }
       
        [HttpGet]
        public IActionResult Get()
        {
            _logger.LogInformation("GET /api/employees called");

            try
            {
                var data = _employeesService.GetAllActiveEmp();
                return Ok(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching active employees");
                return StatusCode(500, "Internal Server Error");
            }
        }
    }
}
