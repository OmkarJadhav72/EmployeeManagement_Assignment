﻿namespace EmployeeManagement.Domain.Entity
{
    public class State
    {
        public int StateId { get; set; }
        public string StateName { get; set; } = null!;
    }
}
