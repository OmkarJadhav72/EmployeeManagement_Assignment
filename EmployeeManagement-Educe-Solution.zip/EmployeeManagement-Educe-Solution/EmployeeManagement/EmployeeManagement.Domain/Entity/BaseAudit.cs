﻿

namespace EmployeeManagement.Domain.Entity
{
    public class BaseAudit
    {
        public bool IsActive { get; set; } = false;
        public int CreatedBy { get; set; } = 1;
        public DateTime CreatedOn { get; set; }= DateTime.Now;
        public int UpdatedBy { get; set; } = 1;
        public DateTime UpdatedOn { get; set; } = DateTime.Now;
    }
}
