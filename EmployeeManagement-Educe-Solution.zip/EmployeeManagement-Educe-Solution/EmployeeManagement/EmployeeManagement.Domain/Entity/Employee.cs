﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Domain.Entity
{
    public class Employee : BaseAudit
    {
        public int EmployeeId { get; set; }

        [Required, StringLength(20)]
        public string FullName { get; set; } = null!;

        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        [Required]
        public string State { get; set; } = null!;

        [Required]
        public string City { get; set; } = null!;

        [Required, DataType(DataType.Date)]
        public DateTime DateOfJoining { get; set; }
    }
}
